<ul class="nav">
			<li class="active"><a href="index.php">Home</a></li>	
			<li><a href="registration.php">Donor Registration</a></li>            
			<li><a href="requests.php">send Request</a></li>
            <li><a href="viewrequest.php">View Request</a></li>
            <li><a href="camps.php">Camps</a></li>
            <li><a href="login.php">log In</a></li>
            <li><a href="search.php">Search</a></li>
            <li><a href="contact.php">Contact Us</a></li>
           	<li><a href="aboutus.php">About</a></li>
            </ul>